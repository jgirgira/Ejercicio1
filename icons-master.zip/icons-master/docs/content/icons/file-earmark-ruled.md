---
title: File earmark ruled
categories:
  - Files and folders
tags:
  - doc
  - document
---
