---
title: File earmark zip
categories:
  - Files and folders
tags:
  - doc
  - document
  - zip
  - archive
  - compress
---
