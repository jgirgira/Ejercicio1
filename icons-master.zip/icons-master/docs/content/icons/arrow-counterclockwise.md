---
title: Arrow counterclockwise
categories:
  - Arrows
tags:
  - arrow
---
