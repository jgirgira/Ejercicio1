---
title: File spreadsheet
categories:
  - Files and folders
tags:
  - doc
  - document
  - excel
  - table
---
