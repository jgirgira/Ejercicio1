---
title: Emoji neutral
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - expressionless
---
