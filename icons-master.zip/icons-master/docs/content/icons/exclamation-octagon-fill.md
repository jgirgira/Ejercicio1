---
title: Alert octagon fill
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
