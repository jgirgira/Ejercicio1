---
title: Eject
categories:
  - UI and keyboard
tags:
  - disc
  - cd
  - dvd
---
