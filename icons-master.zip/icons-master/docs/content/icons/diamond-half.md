---
title: Diamond half fill
categories:
  - Shapes
tags:
  - shape
---
