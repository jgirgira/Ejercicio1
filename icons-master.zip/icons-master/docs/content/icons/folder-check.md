---
title: Folder check
categories:
  - Files and folders
tags:
  - directory
  - check
  - verified
---
