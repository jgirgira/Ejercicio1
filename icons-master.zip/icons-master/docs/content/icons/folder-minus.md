---
title: Folder minus
categories:
  - Files and folders
tags:
  - directory
  - delete
  - remove
---
