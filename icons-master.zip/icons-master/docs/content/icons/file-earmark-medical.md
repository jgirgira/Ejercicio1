---
title: File earmark medical
categories:
  - Files and folders
tags:
  - doc
  - document
  - medical
  - hospital
  - health
---
