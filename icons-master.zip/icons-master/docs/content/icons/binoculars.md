---
title: Binoculars
categories:
  - Real world
tags:
  - distance
  - view
---
